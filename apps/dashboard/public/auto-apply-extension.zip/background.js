const ML_BACKEND_URL = "https://autoapply-scraper-backend.onrender.com/api/ml/fill-form";
const PRIMARY_BACKEND_URL = "https://autoapply-backend-wkqq.onrender.com/api/auth/track-application";

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "FILL_FORM") {
        handleFillForm(request, sendResponse);
        return true; // Indicates async response
    }
});

async function handleFillForm(request, sendResponse) {
    try {
        const { userData } = await chrome.storage.local.get(['userData']);
        
        if (!userData) {
            sendResponse({ success: false, error: "Profile incomplete. Please login and complete your profile on the dashboard." });
            return;
        }

        const response = await fetch(ML_BACKEND_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                form_fields: request.formFields,
                form_html: request.formHtml,
                user_data: userData
            })
        });

        if (!response.ok) {
            throw new Error(`ML Backend error! status: ${response.status}`);
        }

        const data = await response.json();
        sendResponse({ success: true, mapping: data.mapping });

    } catch (error) {
        console.error("Error communicating with ML backend:", error);
        sendResponse({ success: false, error: error.message });
    }
}
