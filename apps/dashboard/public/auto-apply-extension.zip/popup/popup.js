const BACKEND_URL = "https://autoapply-backend-wkqq.onrender.com";
const DASHBOARD_URL = "autoapply-dashboard-plum.vercel.app"; // Update this to your exact Vercel URL if different

document.addEventListener('DOMContentLoaded', async () => {
    const authView = document.getElementById('auth-view');
    const mainView = document.getElementById('main-view');
    const authError = document.getElementById('auth-error');
    const profileWarning = document.getElementById('profile-warning');
    const profileSuccess = document.getElementById('profile-success');

    // Check if already logged in
    chrome.storage.local.get(['token'], async (result) => {
        if (result.token) {
            await showMainView(result.token);
        } else {
            authView.classList.remove('hidden');
        }
    });

    // Email/Password Login
    document.getElementById('btn-login').addEventListener('click', async () => {
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        if (!email || !password) {
            showError("Please enter email and password");
            return;
        }

        try {
            const res = await fetch(`${BACKEND_URL}/api/auth/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            const data = await res.json();
            
            if (!res.ok) throw new Error(data.error || 'Login failed');
            
            await chrome.storage.local.set({ token: data.token });
            await showMainView(data.token);
        } catch (e) {
            showError(e.message);
        }
    });

    // Google Login
    document.getElementById('btn-google').addEventListener('click', () => {
        chrome.identity.getAuthToken({ interactive: true }, async (token) => {
            if (chrome.runtime.lastError) {
                showError(chrome.runtime.lastError.message);
                return;
            }
            // Send the Google token (access_token/id_token) to the backend
            // For chrome.identity.getAuthToken, it returns an access token.
            // Our backend expects `credential` which is usually an idToken, 
            // but we can adjust backend or just pass it. Assuming backend handles it.
            try {
                // To keep it simple, we use the Google token as credential
                const res = await fetch(`${BACKEND_URL}/api/auth/google`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ credential: token }) 
                });
                const data = await res.json();
                
                if (!res.ok) throw new Error(data.error || 'Google login failed');
                
                await chrome.storage.local.set({ token: data.token });
                await showMainView(data.token);
            } catch (e) {
                showError(e.message);
            }
        });
    });

    document.getElementById('btn-logout').addEventListener('click', () => {
        chrome.storage.local.remove(['token', 'userData']);
        authView.classList.remove('hidden');
        mainView.classList.add('hidden');
    });

    // Dashboard Links
    const openDash = () => chrome.tabs.create({ url: DASHBOARD_URL });
    document.querySelectorAll('#btn-dashboard').forEach(btn => btn.addEventListener('click', openDash));

    const btnForceApply = document.getElementById('btn-force-apply');
    const btnMarkSubmitted = document.getElementById('btn-mark-submitted');
    const trackSuccess = document.getElementById('track-success');

    btnForceApply.addEventListener('click', () => {
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
            if (tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, {action: "FORCE_AUTO_APPLY"});
            }
        });
    });

    btnMarkSubmitted.addEventListener('click', () => {
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
            if (tabs[0]) {
                btnMarkSubmitted.innerText = 'Saving...';
                chrome.tabs.sendMessage(tabs[0].id, {action: "GET_PAGE_INFO"}, async (response) => {
                    if (response && response.jobTitle && response.companyName) {
                        try {
                            const { token } = await chrome.storage.local.get(['token']);
                            const res = await fetch(`${BACKEND_URL}/api/extension/track`, {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'Authorization': `Bearer ${token}`
                                },
                                body: JSON.stringify({
                                    jobTitle: response.jobTitle,
                                    companyName: response.companyName,
                                    jobUrl: response.jobUrl
                                })
                            });
                            
                            if (res.ok) {
                                btnMarkSubmitted.classList.add('hidden');
                                trackSuccess.classList.remove('hidden');
                            } else {
                                btnMarkSubmitted.innerText = 'Error! Try Again';
                            }
                        } catch (e) {
                            btnMarkSubmitted.innerText = 'Error! Try Again';
                        }
                    } else {
                        btnMarkSubmitted.innerText = 'Failed to extract job info';
                    }
                });
            }
        });
    });

    function showError(msg) {
        authError.innerText = msg;
        authError.classList.remove('hidden');
    }

    async function showMainView(token) {
        authView.classList.add('hidden');
        mainView.classList.remove('hidden');
        authError.classList.add('hidden');

        try {
            const res = await fetch(`${BACKEND_URL}/api/extension/user-data`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            const data = await res.json();

            if (res.status === 404 && data.complete_profile_required) {
                profileWarning.classList.remove('hidden');
                profileSuccess.classList.add('hidden');
                document.getElementById('btn-force-apply').style.display = 'none';
                await chrome.storage.local.remove('userData'); // Ensure background.js knows it's incomplete
            } else if (res.ok) {
                profileSuccess.classList.remove('hidden');
                profileWarning.classList.add('hidden');
                document.getElementById('btn-force-apply').style.display = 'block';
                // Save user data securely in local storage so background.js can use it
                await chrome.storage.local.set({ userData: data.userData });
            } else {
                // Token might be expired
                throw new Error("Session expired");
            }
        } catch (e) {
            console.error(e);
            chrome.storage.local.remove(['token', 'userData']);
            authView.classList.remove('hidden');
            mainView.classList.add('hidden');
        }
    }
});
