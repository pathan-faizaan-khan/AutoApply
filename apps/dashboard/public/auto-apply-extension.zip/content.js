// Advanced heuristic to detect job application pages
function isJobPage() {
    const url = window.location.href.toLowerCase();
    
    const atsDomains = [
        'greenhouse.io', 'lever.co', 'workday.com', 'myworkdayjobs.com',
        'bamboohr.com', 'icims.com', 'smartrecruiters.com', 'ashbyhq.com',
        'breezy.hr', 'workable.com'
    ];
    const isAts = atsDomains.some(domain => url.includes(domain));
    
    const text = document.body.innerText.toLowerCase();
    const hasJobKeywords = url.includes('job') || url.includes('career') || url.includes('apply');
    const isGenericJob = hasJobKeywords && (text.includes('resume') || text.includes('cv') || text.includes('cover letter'));
    
    return isAts || isGenericJob; // Don't rely on strict <form> tag, single-page apps use arbitrary divs
}

// Deep query selector that pierces shadow DOMs
function querySelectorAllDeep(selector, root = document) {
    let results = Array.from(root.querySelectorAll(selector));
    
    const elements = root.querySelectorAll('*');
    for (const el of elements) {
        if (el.shadowRoot) {
            results = results.concat(querySelectorAllDeep(selector, el.shadowRoot));
        }
    }
    return results;
}

// Fuzzy logic to extract meaningful label context
function getContextText(el) {
    let label = '';
    
    // 1. Check native labels (id match)
    if (el.id) {
        const root = el.getRootNode();
        const lbl = root.querySelector(`label[for="${el.id}"]`);
        if (lbl) label = lbl.innerText.trim();
    }
    
    // 2. Wrapping label
    if (!label) {
        const wrap = el.closest('label');
        if (wrap) {
            const clone = wrap.cloneNode(true);
            const inputInside = clone.querySelector('input, select, textarea');
            if (inputInside) inputInside.remove();
            label = clone.innerText.trim();
        }
    }
    
    // 3. Aria attributes or placeholder
    if (!label) {
        label = el.getAttribute('aria-label') || el.getAttribute('name') || el.placeholder || '';
    }
    
    // 4. Preceding sibling span or div text (common in Workday/Lever)
    if (!label && el.parentElement) {
        const prev = el.previousElementSibling;
        if (prev && ['DIV', 'SPAN', 'P'].includes(prev.tagName) && prev.innerText.trim()) {
            label = prev.innerText.trim();
        }
    }

    return label.substring(0, 100); // keep it sane
}

function extractFormFields() {
    const fields = [];
    const inputs = querySelectorAllDeep('input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="image"]), select, textarea');
    
    // We add an auto-generated unique id to elements without one so we can find them later securely
    inputs.forEach((input, index) => {
        if (['file'].includes(input.type)) return; // File uploads handled separately usually
        
        if (!input.dataset.autoApplyId) {
            input.dataset.autoApplyId = `aa_${index}_${Math.random().toString(36).substr(2, 9)}`;
        }
        
        let labelText = getContextText(input);
        
        let options = [];
        if (input.tagName.toLowerCase() === 'select') {
            options = Array.from(input.options).map(opt => opt.value || opt.text).filter(v => v);
        }

        fields.push({
            tag: input.tagName.toLowerCase(),
            type: input.type || 'text',
            id: input.id || '',
            name: input.name || '',
            autoApplyId: input.dataset.autoApplyId,
            label: labelText,
            options: options.length > 0 ? options : undefined
        });
    });

    // Build a token-efficient linear representation of the form
    const formContextEl = document.querySelector('form') || document.body;
    let contextText = "";

    function traverse(node) {
        if (node.nodeType === Node.TEXT_NODE) {
            const text = node.textContent.trim();
            if (text) contextText += text + " ";
        } else if (node.nodeType === Node.ELEMENT_NODE) {
            const tag = node.tagName.toLowerCase();
            if (['script', 'style', 'noscript', 'svg'].includes(tag)) return;

            // Simple visibility check (avoids expensive getComputedStyle for every node if possible, 
            // but we'll do a basic check)
            if (node.style && (node.style.display === 'none' || node.style.visibility === 'hidden')) return;

            if (['input', 'select', 'textarea'].includes(tag)) {
                if (['hidden', 'submit', 'button', 'image', 'file'].includes(node.type)) return;
                
                let fieldRep = `[FIELD:${node.dataset.autoApplyId}`;
                if (node.name) fieldRep += ` name="${node.name}"`;
                if (tag === 'select') {
                     const opts = Array.from(node.options).map(o => o.text.trim()).filter(Boolean).join(',');
                     if (opts) fieldRep += ` options=(${opts})`;
                }
                fieldRep += `] `;
                contextText += fieldRep;
            } else {
                for (const child of node.childNodes) {
                    traverse(child);
                }
            }
        }
    }
    
    traverse(formContextEl);
    contextText = contextText.replace(/\s+/g, ' ').trim();
    
    return { fields, contextHtml: contextText.substring(0, 10000) }; // send up to 10k chars of dense context
}

if (isJobPage()) {
    injectAutoApplyButton();
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "FORCE_AUTO_APPLY") {
        if (!document.getElementById('auto-apply-btn')) injectAutoApplyButton();
        setTimeout(() => {
            const btn = document.getElementById('auto-apply-btn');
            if (btn) btn.click();
        }, 100);
    }
    if (request.action === "GET_PAGE_INFO") {
        const jobTitle = document.querySelector('h1')?.innerText || document.title || "Unknown Role";
        const companyName = window.location.hostname.replace('www.', '');
        sendResponse({
            jobTitle,
            companyName,
            jobUrl: window.location.href
        });
    }
});

function injectAutoApplyButton() {
    if (document.getElementById('auto-apply-btn')) return;

    const btn = document.createElement('button');
    btn.id = 'auto-apply-btn';
    btn.innerText = '✨ Apply with Auto-Apply';
    btn.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        z-index: 2147483647; /* Max z-index to stay on top of anything */
        background: linear-gradient(135deg, #6366f1, #a855f7);
        color: #fff;
        border: none;
        padding: 15px 24px;
        border-radius: 50px;
        font-family: 'Inter', sans-serif;
        font-weight: 600;
        font-size: 16px;
        cursor: pointer;
        box-shadow: 0 10px 25px rgba(99, 102, 241, 0.4);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    `;
    
    btn.onmouseover = () => btn.style.transform = 'scale(1.05)';
    btn.onmouseout = () => btn.style.transform = 'scale(1)';

    btn.onclick = async () => {
        btn.innerText = '⏳ Analyzing form...';
        
        const extracted = extractFormFields();

        chrome.runtime.sendMessage(
            { action: "FILL_FORM", formFields: extracted.fields, formHtml: extracted.contextHtml },
            (response) => {
                if (response && response.success) {
                    btn.innerText = '✅ Form Filled!';
                    fillFormInputs(response.mapping);
                } else {
                    btn.innerText = '❌ Failed to process';
                    if (response?.error) alert("Auto-Apply Error: " + response.error);
                }
                setTimeout(() => { btn.innerText = '✨ Apply with Auto-Apply'; }, 4000);
            }
        );
    };

    document.documentElement.appendChild(btn); // Append to root to avoid layout shifts
}

function setNativeValue(el, value) {
    try {
        const tag = el.tagName.toLowerCase();
        let proto = window.HTMLInputElement.prototype;
        if (tag === 'textarea') proto = window.HTMLTextAreaElement.prototype;
        else if (tag === 'select') proto = window.HTMLSelectElement.prototype;

        const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
        if (setter) {
            setter.call(el, value);
        } else {
            el.value = value;
        }
    } catch (e) {
        el.value = value;
    }
}

function simulateEvents(el) {
    el.dispatchEvent(new Event('focus', { bubbles: true }));
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Tab' }));
}

function fillFormInputs(mapping) {
    if (!mapping) return;
    
    // mapping returns keys as our generated autoApplyId
    for (const [key, value] of Object.entries(mapping)) {
        const inputs = querySelectorAllDeep(`[data-auto-apply-id="${key}"]`);
        const input = inputs[0];
        
        if (input) {
            if (input.type === 'checkbox' || input.type === 'radio') {
                const shouldCheck = typeof value === 'boolean' ? value : (value.toString().toLowerCase() === 'true' || value === input.value);
                if (input.checked !== shouldCheck) {
                    input.click(); // Browsers respect this as a trusted action often
                    simulateEvents(input);
                }
            } else if (input.tagName.toLowerCase() === 'select') {
                setNativeValue(input, value);
                simulateEvents(input);
            } else {
                setNativeValue(input, value);
                simulateEvents(input);
            }
            input.style.backgroundColor = 'rgba(99, 102, 241, 0.1)'; // Highlight filled inputs lightly
        }
    }
}
